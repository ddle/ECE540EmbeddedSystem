Portland State University, ECE 540 Embedded System
Project 2: RoJoBOT World
Copyright by Dung Le and Eric Krause

ARCHIVE CONTENTS:

	docs - All documentation for project
		-	Project 2 Theory of Operation
		
	firmware - Picoblaze files ( bot_control source, JTAG loader script )
		-	bot_control.psm	- robot control picoblaze program
		-	JTAG loader application
		- 	Picoblaze compiler
		-	loader script (compiles source and loads via JTAG)
		- 	etc
		
	icon_builder
		- icon (Bee.png) 
		- coe-generator python script

	hdl	- all hardware code for project, including supplied IP from 3.1
		- 	new/altered files are:
			-	colorizer.v	(new)
			-	Icon.v	(new)
			-	nexys3_bot_inf.v (modified)
			-	nexys3fpga.v (modified)
			-	uart_rx6.v (new)
			-	uart_tx6.v (new)
		- other files are unchanged from code supplied in 2a/2b	
			
	synth - addl. files necessary for synthesis
		- ucf file (modified)
		- icon ROM files

world_map - all map files
	- world_map.ngc (new map generated with BOTWorld Dev Kit)
	- world_map_2b.ngc (map supplied from part 2b of project)
	- directory <newmaps> contains source files for new map

	