/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x1048c146 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/cob/Documents/My Dropbox/541-SoC/project/project3/stage4/hdl/MontgomeryExponential.v";
static unsigned int ng1[] = {1U, 0U};
static unsigned int ng2[] = {2U, 0U};
static unsigned int ng3[] = {4U, 0U};
static unsigned int ng4[] = {16U, 0U};
static unsigned int ng5[] = {8U, 0U};
static int ng6[] = {128, 0};
static int ng7[] = {1, 0};
static unsigned int ng8[] = {32U, 0U};
static int ng9[] = {0, 0};
static int ng10[] = {0, 0, 0, 0, 0, 0, 0, 0};
static unsigned int ng11[] = {1884291067U, 0U, 2682259406U, 0U, 838205952U, 0U, 261894U, 0U};
static int ng12[] = {1, 0, 0, 0, 0, 0, 0, 0};
static unsigned int ng13[] = {65535U, 0U, 0U, 0U, 0U, 0U, 0U, 0U};



static void Always_78_0(char *t0)
{
    char t4[8];
    char *t1;
    char *t2;
    char *t3;
    char *t5;
    char *t6;
    unsigned int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    char *t12;
    char *t13;
    char *t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    char *t29;
    char *t30;

LAB0:    t1 = (t0 + 4028U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(78, ng0);
    t2 = (t0 + 4512);
    *((int *)t2) = 1;
    t3 = (t0 + 4056);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(78, ng0);

LAB5:    xsi_set_current_line(79, ng0);
    t5 = (t0 + 1528U);
    t6 = *((char **)t5);
    memset(t4, 0, 8);
    t5 = (t6 + 4);
    t7 = *((unsigned int *)t5);
    t8 = (~(t7));
    t9 = *((unsigned int *)t6);
    t10 = (t9 & t8);
    t11 = (t10 & 1U);
    if (t11 != 0)
        goto LAB9;

LAB7:    if (*((unsigned int *)t5) == 0)
        goto LAB6;

LAB8:    t12 = (t4 + 4);
    *((unsigned int *)t4) = 1;
    *((unsigned int *)t12) = 1;

LAB9:    t13 = (t4 + 4);
    t14 = (t6 + 4);
    t15 = *((unsigned int *)t6);
    t16 = (~(t15));
    *((unsigned int *)t4) = t16;
    *((unsigned int *)t13) = 0;
    if (*((unsigned int *)t14) != 0)
        goto LAB11;

LAB10:    t21 = *((unsigned int *)t4);
    *((unsigned int *)t4) = (t21 & 1U);
    t22 = *((unsigned int *)t13);
    *((unsigned int *)t13) = (t22 & 1U);
    t23 = (t4 + 4);
    t24 = *((unsigned int *)t23);
    t25 = (~(t24));
    t26 = *((unsigned int *)t4);
    t27 = (t26 & t25);
    t28 = (t27 != 0);
    if (t28 > 0)
        goto LAB12;

LAB13:    xsi_set_current_line(82, ng0);
    t2 = (t0 + 2492);
    t3 = (t2 + 36U);
    t5 = *((char **)t3);
    t6 = (t0 + 2400);
    xsi_vlogvar_wait_assign_value(t6, t5, 0, 0, 6, 0LL);

LAB14:    goto LAB2;

LAB6:    *((unsigned int *)t4) = 1;
    goto LAB9;

LAB11:    t17 = *((unsigned int *)t4);
    t18 = *((unsigned int *)t14);
    *((unsigned int *)t4) = (t17 | t18);
    t19 = *((unsigned int *)t13);
    t20 = *((unsigned int *)t14);
    *((unsigned int *)t13) = (t19 | t20);
    goto LAB10;

LAB12:    xsi_set_current_line(80, ng0);
    t29 = ((char*)((ng1)));
    t30 = (t0 + 2400);
    xsi_vlogvar_wait_assign_value(t30, t29, 0, 0, 6, 0LL);
    goto LAB14;

}

static void Always_85_1(char *t0)
{
    char t18[8];
    char t22[8];
    char t28[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int t8;
    char *t9;
    char *t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    char *t17;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t29;
    unsigned int t30;
    unsigned int t31;
    char *t32;
    char *t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    unsigned int t40;
    char *t41;
    char *t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    unsigned int t50;
    int t51;
    int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    unsigned int t57;
    unsigned int t58;
    char *t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    unsigned int t63;
    unsigned int t64;
    char *t65;
    char *t66;

LAB0:    t1 = (t0 + 4172U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(85, ng0);
    t2 = (t0 + 4520);
    *((int *)t2) = 1;
    t3 = (t0 + 4200);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(85, ng0);

LAB5:    xsi_set_current_line(86, ng0);
    t4 = (t0 + 2400);
    t5 = (t4 + 36U);
    t6 = *((char **)t5);

LAB6:    t7 = ((char*)((ng1)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 6, t7, 6);
    if (t8 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng2)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 6, t2, 6);
    if (t8 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng3)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 6, t2, 6);
    if (t8 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng4)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 6, t2, 6);
    if (t8 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng5)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 6, t2, 6);
    if (t8 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng8)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 6, t2, 6);
    if (t8 == 1)
        goto LAB17;

LAB18:
LAB20:
LAB19:    xsi_set_current_line(114, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2492);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 6);

LAB21:    goto LAB2;

LAB7:    xsi_set_current_line(87, ng0);
    t9 = (t0 + 1528U);
    t10 = *((char **)t9);
    t9 = (t10 + 4);
    t11 = *((unsigned int *)t9);
    t12 = (~(t11));
    t13 = *((unsigned int *)t10);
    t14 = (t13 & t12);
    t15 = (t14 != 0);
    if (t15 > 0)
        goto LAB22;

LAB23:    xsi_set_current_line(90, ng0);
    t2 = ((char*)((ng1)));
    t3 = (t0 + 2492);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 6);

LAB24:    goto LAB21;

LAB9:    xsi_set_current_line(92, ng0);
    t3 = ((char*)((ng3)));
    t4 = (t0 + 2492);
    xsi_vlogvar_assign_value(t4, t3, 0, 0, 6);
    goto LAB21;

LAB11:    xsi_set_current_line(95, ng0);
    t3 = (t0 + 1620U);
    t4 = *((char **)t3);
    memset(t18, 0, 8);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 & 1U);
    if (t15 != 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t3) != 0)
        goto LAB27;

LAB28:    t7 = (t18 + 4);
    t19 = *((unsigned int *)t18);
    t20 = *((unsigned int *)t7);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB29;

LAB30:    memcpy(t28, t18, 8);

LAB31:    t59 = (t28 + 4);
    t60 = *((unsigned int *)t59);
    t61 = (~(t60));
    t62 = *((unsigned int *)t28);
    t63 = (t62 & t61);
    t64 = (t63 != 0);
    if (t64 > 0)
        goto LAB39;

LAB40:    xsi_set_current_line(98, ng0);
    t2 = ((char*)((ng3)));
    t3 = (t0 + 2492);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 6);

LAB41:    goto LAB21;

LAB13:    xsi_set_current_line(99, ng0);
    t3 = (t0 + 1620U);
    t4 = *((char **)t3);
    memset(t18, 0, 8);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 & 1U);
    if (t15 != 0)
        goto LAB42;

LAB43:    if (*((unsigned int *)t3) != 0)
        goto LAB44;

LAB45:    t7 = (t18 + 4);
    t19 = *((unsigned int *)t18);
    t20 = (!(t19));
    t21 = *((unsigned int *)t7);
    t23 = (t20 || t21);
    if (t23 > 0)
        goto LAB46;

LAB47:    memcpy(t28, t18, 8);

LAB48:    t59 = (t28 + 4);
    t56 = *((unsigned int *)t59);
    t57 = (~(t56));
    t58 = *((unsigned int *)t28);
    t60 = (t58 & t57);
    t61 = (t60 != 0);
    if (t61 > 0)
        goto LAB56;

LAB57:    xsi_set_current_line(102, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 2492);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 6);

LAB58:    goto LAB21;

LAB15:    xsi_set_current_line(103, ng0);
    t3 = (t0 + 2308);
    t4 = (t3 + 36U);
    t5 = *((char **)t4);
    t7 = ((char*)((ng6)));
    t9 = ((char*)((ng7)));
    memset(t18, 0, 8);
    xsi_vlog_unsigned_minus(t18, 32, t7, 32, t9, 32);
    memset(t22, 0, 8);
    t10 = (t5 + 4);
    t16 = (t18 + 4);
    t11 = *((unsigned int *)t5);
    t12 = *((unsigned int *)t18);
    t13 = (t11 ^ t12);
    t14 = *((unsigned int *)t10);
    t15 = *((unsigned int *)t16);
    t19 = (t14 ^ t15);
    t20 = (t13 | t19);
    t21 = *((unsigned int *)t10);
    t23 = *((unsigned int *)t16);
    t24 = (t21 | t23);
    t25 = (~(t24));
    t26 = (t20 & t25);
    if (t26 != 0)
        goto LAB62;

LAB59:    if (t24 != 0)
        goto LAB61;

LAB60:    *((unsigned int *)t22) = 1;

LAB62:    t32 = (t22 + 4);
    t27 = *((unsigned int *)t32);
    t29 = (~(t27));
    t30 = *((unsigned int *)t22);
    t31 = (t30 & t29);
    t34 = (t31 != 0);
    if (t34 > 0)
        goto LAB63;

LAB64:    xsi_set_current_line(105, ng0);
    t2 = (t0 + 1620U);
    t3 = *((char **)t2);
    memset(t18, 0, 8);
    t2 = (t3 + 4);
    t11 = *((unsigned int *)t2);
    t12 = (~(t11));
    t13 = *((unsigned int *)t3);
    t14 = (t13 & t12);
    t15 = (t14 & 1U);
    if (t15 != 0)
        goto LAB66;

LAB67:    if (*((unsigned int *)t2) != 0)
        goto LAB68;

LAB69:    t5 = (t18 + 4);
    t19 = *((unsigned int *)t18);
    t20 = *((unsigned int *)t5);
    t21 = (t19 || t20);
    if (t21 > 0)
        goto LAB70;

LAB71:    memcpy(t28, t18, 8);

LAB72:    t42 = (t28 + 4);
    t60 = *((unsigned int *)t42);
    t61 = (~(t60));
    t62 = *((unsigned int *)t28);
    t63 = (t62 & t61);
    t64 = (t63 != 0);
    if (t64 > 0)
        goto LAB80;

LAB81:    xsi_set_current_line(108, ng0);
    t2 = ((char*)((ng5)));
    t3 = (t0 + 2492);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 6);

LAB82:
LAB65:    goto LAB21;

LAB17:    xsi_set_current_line(109, ng0);
    t3 = (t0 + 1528U);
    t4 = *((char **)t3);
    memset(t18, 0, 8);
    t3 = (t4 + 4);
    t11 = *((unsigned int *)t3);
    t12 = (~(t11));
    t13 = *((unsigned int *)t4);
    t14 = (t13 & t12);
    t15 = (t14 & 1U);
    if (t15 != 0)
        goto LAB86;

LAB84:    if (*((unsigned int *)t3) == 0)
        goto LAB83;

LAB85:    t5 = (t18 + 4);
    *((unsigned int *)t18) = 1;
    *((unsigned int *)t5) = 1;

LAB86:    t7 = (t18 + 4);
    t9 = (t4 + 4);
    t19 = *((unsigned int *)t4);
    t20 = (~(t19));
    *((unsigned int *)t18) = t20;
    *((unsigned int *)t7) = 0;
    if (*((unsigned int *)t9) != 0)
        goto LAB88;

LAB87:    t26 = *((unsigned int *)t18);
    *((unsigned int *)t18) = (t26 & 1U);
    t27 = *((unsigned int *)t7);
    *((unsigned int *)t7) = (t27 & 1U);
    t10 = (t18 + 4);
    t29 = *((unsigned int *)t10);
    t30 = (~(t29));
    t31 = *((unsigned int *)t18);
    t34 = (t31 & t30);
    t35 = (t34 != 0);
    if (t35 > 0)
        goto LAB89;

LAB90:    xsi_set_current_line(112, ng0);
    t2 = ((char*)((ng8)));
    t3 = (t0 + 2492);
    xsi_vlogvar_assign_value(t3, t2, 0, 0, 6);

LAB91:    goto LAB21;

LAB22:    xsi_set_current_line(88, ng0);
    t16 = ((char*)((ng2)));
    t17 = (t0 + 2492);
    xsi_vlogvar_assign_value(t17, t16, 0, 0, 6);
    goto LAB24;

LAB25:    *((unsigned int *)t18) = 1;
    goto LAB28;

LAB27:    t5 = (t18 + 4);
    *((unsigned int *)t18) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB28;

LAB29:    t9 = (t0 + 1804U);
    t10 = *((char **)t9);
    memset(t22, 0, 8);
    t9 = (t10 + 4);
    t23 = *((unsigned int *)t9);
    t24 = (~(t23));
    t25 = *((unsigned int *)t10);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB32;

LAB33:    if (*((unsigned int *)t9) != 0)
        goto LAB34;

LAB35:    t29 = *((unsigned int *)t18);
    t30 = *((unsigned int *)t22);
    t31 = (t29 & t30);
    *((unsigned int *)t28) = t31;
    t17 = (t18 + 4);
    t32 = (t22 + 4);
    t33 = (t28 + 4);
    t34 = *((unsigned int *)t17);
    t35 = *((unsigned int *)t32);
    t36 = (t34 | t35);
    *((unsigned int *)t33) = t36;
    t37 = *((unsigned int *)t33);
    t38 = (t37 != 0);
    if (t38 == 1)
        goto LAB36;

LAB37:
LAB38:    goto LAB31;

LAB32:    *((unsigned int *)t22) = 1;
    goto LAB35;

LAB34:    t16 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t16) = 1;
    goto LAB35;

LAB36:    t39 = *((unsigned int *)t28);
    t40 = *((unsigned int *)t33);
    *((unsigned int *)t28) = (t39 | t40);
    t41 = (t18 + 4);
    t42 = (t22 + 4);
    t43 = *((unsigned int *)t18);
    t44 = (~(t43));
    t45 = *((unsigned int *)t41);
    t46 = (~(t45));
    t47 = *((unsigned int *)t22);
    t48 = (~(t47));
    t49 = *((unsigned int *)t42);
    t50 = (~(t49));
    t51 = (t44 & t46);
    t52 = (t48 & t50);
    t53 = (~(t51));
    t54 = (~(t52));
    t55 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t55 & t53);
    t56 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t56 & t54);
    t57 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t57 & t53);
    t58 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t58 & t54);
    goto LAB38;

LAB39:    xsi_set_current_line(96, ng0);
    t65 = ((char*)((ng4)));
    t66 = (t0 + 2492);
    xsi_vlogvar_assign_value(t66, t65, 0, 0, 6);
    goto LAB41;

LAB42:    *((unsigned int *)t18) = 1;
    goto LAB45;

LAB44:    t5 = (t18 + 4);
    *((unsigned int *)t18) = 1;
    *((unsigned int *)t5) = 1;
    goto LAB45;

LAB46:    t9 = (t0 + 1804U);
    t10 = *((char **)t9);
    memset(t22, 0, 8);
    t9 = (t10 + 4);
    t24 = *((unsigned int *)t9);
    t25 = (~(t24));
    t26 = *((unsigned int *)t10);
    t27 = (t26 & t25);
    t29 = (t27 & 1U);
    if (t29 != 0)
        goto LAB49;

LAB50:    if (*((unsigned int *)t9) != 0)
        goto LAB51;

LAB52:    t30 = *((unsigned int *)t18);
    t31 = *((unsigned int *)t22);
    t34 = (t30 | t31);
    *((unsigned int *)t28) = t34;
    t17 = (t18 + 4);
    t32 = (t22 + 4);
    t33 = (t28 + 4);
    t35 = *((unsigned int *)t17);
    t36 = *((unsigned int *)t32);
    t37 = (t35 | t36);
    *((unsigned int *)t33) = t37;
    t38 = *((unsigned int *)t33);
    t39 = (t38 != 0);
    if (t39 == 1)
        goto LAB53;

LAB54:
LAB55:    goto LAB48;

LAB49:    *((unsigned int *)t22) = 1;
    goto LAB52;

LAB51:    t16 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t16) = 1;
    goto LAB52;

LAB53:    t40 = *((unsigned int *)t28);
    t43 = *((unsigned int *)t33);
    *((unsigned int *)t28) = (t40 | t43);
    t41 = (t18 + 4);
    t42 = (t22 + 4);
    t44 = *((unsigned int *)t41);
    t45 = (~(t44));
    t46 = *((unsigned int *)t18);
    t51 = (t46 & t45);
    t47 = *((unsigned int *)t42);
    t48 = (~(t47));
    t49 = *((unsigned int *)t22);
    t52 = (t49 & t48);
    t50 = (~(t51));
    t53 = (~(t52));
    t54 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t54 & t50);
    t55 = *((unsigned int *)t33);
    *((unsigned int *)t33) = (t55 & t53);
    goto LAB55;

LAB56:    xsi_set_current_line(100, ng0);
    t65 = ((char*)((ng4)));
    t66 = (t0 + 2492);
    xsi_vlogvar_assign_value(t66, t65, 0, 0, 6);
    goto LAB58;

LAB61:    t17 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t17) = 1;
    goto LAB62;

LAB63:    xsi_set_current_line(104, ng0);
    t33 = ((char*)((ng8)));
    t41 = (t0 + 2492);
    xsi_vlogvar_assign_value(t41, t33, 0, 0, 6);
    goto LAB65;

LAB66:    *((unsigned int *)t18) = 1;
    goto LAB69;

LAB68:    t4 = (t18 + 4);
    *((unsigned int *)t18) = 1;
    *((unsigned int *)t4) = 1;
    goto LAB69;

LAB70:    t7 = (t0 + 1804U);
    t9 = *((char **)t7);
    memset(t22, 0, 8);
    t7 = (t9 + 4);
    t23 = *((unsigned int *)t7);
    t24 = (~(t23));
    t25 = *((unsigned int *)t9);
    t26 = (t25 & t24);
    t27 = (t26 & 1U);
    if (t27 != 0)
        goto LAB73;

LAB74:    if (*((unsigned int *)t7) != 0)
        goto LAB75;

LAB76:    t29 = *((unsigned int *)t18);
    t30 = *((unsigned int *)t22);
    t31 = (t29 & t30);
    *((unsigned int *)t28) = t31;
    t16 = (t18 + 4);
    t17 = (t22 + 4);
    t32 = (t28 + 4);
    t34 = *((unsigned int *)t16);
    t35 = *((unsigned int *)t17);
    t36 = (t34 | t35);
    *((unsigned int *)t32) = t36;
    t37 = *((unsigned int *)t32);
    t38 = (t37 != 0);
    if (t38 == 1)
        goto LAB77;

LAB78:
LAB79:    goto LAB72;

LAB73:    *((unsigned int *)t22) = 1;
    goto LAB76;

LAB75:    t10 = (t22 + 4);
    *((unsigned int *)t22) = 1;
    *((unsigned int *)t10) = 1;
    goto LAB76;

LAB77:    t39 = *((unsigned int *)t28);
    t40 = *((unsigned int *)t32);
    *((unsigned int *)t28) = (t39 | t40);
    t33 = (t18 + 4);
    t41 = (t22 + 4);
    t43 = *((unsigned int *)t18);
    t44 = (~(t43));
    t45 = *((unsigned int *)t33);
    t46 = (~(t45));
    t47 = *((unsigned int *)t22);
    t48 = (~(t47));
    t49 = *((unsigned int *)t41);
    t50 = (~(t49));
    t8 = (t44 & t46);
    t51 = (t48 & t50);
    t53 = (~(t8));
    t54 = (~(t51));
    t55 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t55 & t53);
    t56 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t56 & t54);
    t57 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t57 & t53);
    t58 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t58 & t54);
    goto LAB79;

LAB80:    xsi_set_current_line(106, ng0);
    t59 = ((char*)((ng4)));
    t65 = (t0 + 2492);
    xsi_vlogvar_assign_value(t65, t59, 0, 0, 6);
    goto LAB82;

LAB83:    *((unsigned int *)t18) = 1;
    goto LAB86;

LAB88:    t21 = *((unsigned int *)t18);
    t23 = *((unsigned int *)t9);
    *((unsigned int *)t18) = (t21 | t23);
    t24 = *((unsigned int *)t7);
    t25 = *((unsigned int *)t9);
    *((unsigned int *)t7) = (t24 | t25);
    goto LAB87;

LAB89:    xsi_set_current_line(110, ng0);
    t16 = ((char*)((ng1)));
    t17 = (t0 + 2492);
    xsi_vlogvar_assign_value(t17, t16, 0, 0, 6);
    goto LAB91;

}

static void Always_121_2(char *t0)
{
    char t11[8];
    char t20[8];
    char t26[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    int t8;
    char *t9;
    char *t10;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t21;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;
    char *t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    unsigned int t38;
    unsigned int t39;
    char *t40;
    char *t41;
    unsigned int t42;
    unsigned int t43;
    unsigned int t44;
    unsigned int t45;
    unsigned int t46;
    unsigned int t47;
    unsigned int t48;
    unsigned int t49;
    int t50;
    unsigned int t51;
    unsigned int t52;
    unsigned int t53;
    unsigned int t54;
    unsigned int t55;
    unsigned int t56;
    char *t57;
    unsigned int t58;
    unsigned int t59;
    unsigned int t60;
    unsigned int t61;
    unsigned int t62;
    char *t63;
    char *t64;

LAB0:    t1 = (t0 + 4316U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(121, ng0);
    t2 = (t0 + 4528);
    *((int *)t2) = 1;
    t3 = (t0 + 4344);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(121, ng0);

LAB5:    xsi_set_current_line(126, ng0);
    t4 = (t0 + 2400);
    t5 = (t4 + 36U);
    t6 = *((char **)t5);

LAB6:    t7 = ((char*)((ng1)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 6, t7, 6);
    if (t8 == 1)
        goto LAB7;

LAB8:    t2 = ((char*)((ng2)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 6, t2, 6);
    if (t8 == 1)
        goto LAB9;

LAB10:    t2 = ((char*)((ng3)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 6, t2, 6);
    if (t8 == 1)
        goto LAB11;

LAB12:    t2 = ((char*)((ng4)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 6, t2, 6);
    if (t8 == 1)
        goto LAB13;

LAB14:    t2 = ((char*)((ng5)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 6, t2, 6);
    if (t8 == 1)
        goto LAB15;

LAB16:    t2 = ((char*)((ng8)));
    t8 = xsi_vlog_unsigned_case_compare(t6, 6, t2, 6);
    if (t8 == 1)
        goto LAB17;

LAB18:
LAB20:
LAB19:    xsi_set_current_line(199, ng0);

LAB75:    xsi_set_current_line(200, ng0);
    t2 = ((char*)((ng13)));
    t3 = (t0 + 2216);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 128, 0LL);
    xsi_set_current_line(201, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 2124);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);

LAB21:    goto LAB2;

LAB7:    xsi_set_current_line(128, ng0);

LAB22:    xsi_set_current_line(129, ng0);
    t9 = ((char*)((ng9)));
    t10 = (t0 + 2124);
    xsi_vlogvar_wait_assign_value(t10, t9, 0, 0, 1, 0LL);
    xsi_set_current_line(130, ng0);
    t2 = ((char*)((ng10)));
    t3 = (t0 + 2216);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 128, 0LL);
    xsi_set_current_line(131, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 2860);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(132, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 3228);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(134, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 2308);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 10, 0LL);
    goto LAB21;

LAB9:    xsi_set_current_line(137, ng0);

LAB23:    xsi_set_current_line(140, ng0);
    t3 = ((char*)((ng11)));
    t4 = (t0 + 3504);
    xsi_vlogvar_wait_assign_value(t4, t3, 0, 0, 128, 0LL);
    goto LAB21;

LAB11:    xsi_set_current_line(148, ng0);

LAB24:    xsi_set_current_line(149, ng0);
    t3 = ((char*)((ng12)));
    t4 = (t0 + 2952);
    xsi_vlogvar_wait_assign_value(t4, t3, 0, 0, 128, 0LL);
    xsi_set_current_line(150, ng0);
    t2 = (t0 + 3504);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 3044);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 128, 0LL);
    xsi_set_current_line(151, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 3228);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(152, ng0);
    t2 = (t0 + 1160U);
    t3 = *((char **)t2);
    t2 = (t0 + 2584);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 128, 0LL);
    xsi_set_current_line(153, ng0);
    t2 = (t0 + 3504);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 2676);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 128, 0LL);
    xsi_set_current_line(154, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 2860);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(155, ng0);
    t2 = (t0 + 1620U);
    t3 = *((char **)t2);
    memset(t11, 0, 8);
    t2 = (t3 + 4);
    t12 = *((unsigned int *)t2);
    t13 = (~(t12));
    t14 = *((unsigned int *)t3);
    t15 = (t14 & t13);
    t16 = (t15 & 1U);
    if (t16 != 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t2) != 0)
        goto LAB27;

LAB28:    t5 = (t11 + 4);
    t17 = *((unsigned int *)t11);
    t18 = *((unsigned int *)t5);
    t19 = (t17 || t18);
    if (t19 > 0)
        goto LAB29;

LAB30:    memcpy(t26, t11, 8);

LAB31:    t57 = (t26 + 4);
    t58 = *((unsigned int *)t57);
    t59 = (~(t58));
    t60 = *((unsigned int *)t26);
    t61 = (t60 & t59);
    t62 = (t61 != 0);
    if (t62 > 0)
        goto LAB39;

LAB40:
LAB41:    goto LAB21;

LAB13:    xsi_set_current_line(162, ng0);

LAB43:    xsi_set_current_line(163, ng0);
    t3 = ((char*)((ng9)));
    t4 = (t0 + 2860);
    xsi_vlogvar_wait_assign_value(t4, t3, 0, 0, 1, 0LL);
    xsi_set_current_line(164, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 3228);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB21;

LAB15:    xsi_set_current_line(167, ng0);

LAB44:    xsi_set_current_line(170, ng0);
    t3 = (t0 + 3412);
    t4 = (t3 + 36U);
    t5 = *((char **)t4);
    t7 = (t0 + 2584);
    xsi_vlogvar_wait_assign_value(t7, t5, 0, 0, 128, 0LL);
    xsi_set_current_line(171, ng0);
    t2 = (t0 + 3412);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 2676);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 128, 0LL);
    xsi_set_current_line(172, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 2860);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(173, ng0);
    t2 = (t0 + 3320);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 2952);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 128, 0LL);
    xsi_set_current_line(174, ng0);
    t2 = (t0 + 3412);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 3044);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 128, 0LL);
    xsi_set_current_line(175, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 3228);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(176, ng0);
    t2 = (t0 + 1620U);
    t3 = *((char **)t2);
    memset(t11, 0, 8);
    t2 = (t3 + 4);
    t12 = *((unsigned int *)t2);
    t13 = (~(t12));
    t14 = *((unsigned int *)t3);
    t15 = (t14 & t13);
    t16 = (t15 & 1U);
    if (t16 != 0)
        goto LAB45;

LAB46:    if (*((unsigned int *)t2) != 0)
        goto LAB47;

LAB48:    t5 = (t11 + 4);
    t17 = *((unsigned int *)t11);
    t18 = *((unsigned int *)t5);
    t19 = (t17 || t18);
    if (t19 > 0)
        goto LAB49;

LAB50:    memcpy(t26, t11, 8);

LAB51:    t57 = (t26 + 4);
    t58 = *((unsigned int *)t57);
    t59 = (~(t58));
    t60 = *((unsigned int *)t26);
    t61 = (t60 & t59);
    t62 = (t61 != 0);
    if (t62 > 0)
        goto LAB59;

LAB60:
LAB61:    goto LAB21;

LAB17:    xsi_set_current_line(189, ng0);

LAB70:    xsi_set_current_line(190, ng0);
    t3 = ((char*)((ng12)));
    t4 = (t0 + 2952);
    xsi_vlogvar_wait_assign_value(t4, t3, 0, 0, 128, 0LL);
    xsi_set_current_line(191, ng0);
    t2 = (t0 + 3320);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 3044);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 128, 0LL);
    xsi_set_current_line(192, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 3228);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(193, ng0);
    t2 = (t0 + 1804U);
    t3 = *((char **)t2);
    t2 = (t3 + 4);
    t12 = *((unsigned int *)t2);
    t13 = (~(t12));
    t14 = *((unsigned int *)t3);
    t15 = (t14 & t13);
    t16 = (t15 != 0);
    if (t16 > 0)
        goto LAB71;

LAB72:
LAB73:    goto LAB21;

LAB25:    *((unsigned int *)t11) = 1;
    goto LAB28;

LAB27:    t4 = (t11 + 4);
    *((unsigned int *)t11) = 1;
    *((unsigned int *)t4) = 1;
    goto LAB28;

LAB29:    t7 = (t0 + 1804U);
    t9 = *((char **)t7);
    memset(t20, 0, 8);
    t7 = (t9 + 4);
    t21 = *((unsigned int *)t7);
    t22 = (~(t21));
    t23 = *((unsigned int *)t9);
    t24 = (t23 & t22);
    t25 = (t24 & 1U);
    if (t25 != 0)
        goto LAB32;

LAB33:    if (*((unsigned int *)t7) != 0)
        goto LAB34;

LAB35:    t27 = *((unsigned int *)t11);
    t28 = *((unsigned int *)t20);
    t29 = (t27 & t28);
    *((unsigned int *)t26) = t29;
    t30 = (t11 + 4);
    t31 = (t20 + 4);
    t32 = (t26 + 4);
    t33 = *((unsigned int *)t30);
    t34 = *((unsigned int *)t31);
    t35 = (t33 | t34);
    *((unsigned int *)t32) = t35;
    t36 = *((unsigned int *)t32);
    t37 = (t36 != 0);
    if (t37 == 1)
        goto LAB36;

LAB37:
LAB38:    goto LAB31;

LAB32:    *((unsigned int *)t20) = 1;
    goto LAB35;

LAB34:    t10 = (t20 + 4);
    *((unsigned int *)t20) = 1;
    *((unsigned int *)t10) = 1;
    goto LAB35;

LAB36:    t38 = *((unsigned int *)t26);
    t39 = *((unsigned int *)t32);
    *((unsigned int *)t26) = (t38 | t39);
    t40 = (t11 + 4);
    t41 = (t20 + 4);
    t42 = *((unsigned int *)t11);
    t43 = (~(t42));
    t44 = *((unsigned int *)t40);
    t45 = (~(t44));
    t46 = *((unsigned int *)t20);
    t47 = (~(t46));
    t48 = *((unsigned int *)t41);
    t49 = (~(t48));
    t8 = (t43 & t45);
    t50 = (t47 & t49);
    t51 = (~(t8));
    t52 = (~(t50));
    t53 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t53 & t51);
    t54 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t54 & t52);
    t55 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t55 & t51);
    t56 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t56 & t52);
    goto LAB38;

LAB39:    xsi_set_current_line(155, ng0);

LAB42:    xsi_set_current_line(156, ng0);
    t63 = (t0 + 1896U);
    t64 = *((char **)t63);
    t63 = (t0 + 3320);
    xsi_vlogvar_wait_assign_value(t63, t64, 0, 0, 128, 0LL);
    xsi_set_current_line(157, ng0);
    t2 = (t0 + 1712U);
    t3 = *((char **)t2);
    t2 = (t0 + 3412);
    xsi_vlogvar_wait_assign_value(t2, t3, 0, 0, 128, 0LL);
    xsi_set_current_line(158, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 2860);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(159, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 3228);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB41;

LAB45:    *((unsigned int *)t11) = 1;
    goto LAB48;

LAB47:    t4 = (t11 + 4);
    *((unsigned int *)t11) = 1;
    *((unsigned int *)t4) = 1;
    goto LAB48;

LAB49:    t7 = (t0 + 1804U);
    t9 = *((char **)t7);
    memset(t20, 0, 8);
    t7 = (t9 + 4);
    t21 = *((unsigned int *)t7);
    t22 = (~(t21));
    t23 = *((unsigned int *)t9);
    t24 = (t23 & t22);
    t25 = (t24 & 1U);
    if (t25 != 0)
        goto LAB52;

LAB53:    if (*((unsigned int *)t7) != 0)
        goto LAB54;

LAB55:    t27 = *((unsigned int *)t11);
    t28 = *((unsigned int *)t20);
    t29 = (t27 & t28);
    *((unsigned int *)t26) = t29;
    t30 = (t11 + 4);
    t31 = (t20 + 4);
    t32 = (t26 + 4);
    t33 = *((unsigned int *)t30);
    t34 = *((unsigned int *)t31);
    t35 = (t33 | t34);
    *((unsigned int *)t32) = t35;
    t36 = *((unsigned int *)t32);
    t37 = (t36 != 0);
    if (t37 == 1)
        goto LAB56;

LAB57:
LAB58:    goto LAB51;

LAB52:    *((unsigned int *)t20) = 1;
    goto LAB55;

LAB54:    t10 = (t20 + 4);
    *((unsigned int *)t20) = 1;
    *((unsigned int *)t10) = 1;
    goto LAB55;

LAB56:    t38 = *((unsigned int *)t26);
    t39 = *((unsigned int *)t32);
    *((unsigned int *)t26) = (t38 | t39);
    t40 = (t11 + 4);
    t41 = (t20 + 4);
    t42 = *((unsigned int *)t11);
    t43 = (~(t42));
    t44 = *((unsigned int *)t40);
    t45 = (~(t44));
    t46 = *((unsigned int *)t20);
    t47 = (~(t46));
    t48 = *((unsigned int *)t41);
    t49 = (~(t48));
    t8 = (t43 & t45);
    t50 = (t47 & t49);
    t51 = (~(t8));
    t52 = (~(t50));
    t53 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t53 & t51);
    t54 = *((unsigned int *)t32);
    *((unsigned int *)t32) = (t54 & t52);
    t55 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t55 & t51);
    t56 = *((unsigned int *)t26);
    *((unsigned int *)t26) = (t56 & t52);
    goto LAB58;

LAB59:    xsi_set_current_line(176, ng0);

LAB62:    xsi_set_current_line(177, ng0);
    t63 = (t0 + 1712U);
    t64 = *((char **)t63);
    t63 = (t0 + 3412);
    xsi_vlogvar_wait_assign_value(t63, t64, 0, 0, 128, 0LL);
    xsi_set_current_line(178, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 2860);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(179, ng0);
    t2 = ((char*)((ng9)));
    t3 = (t0 + 3228);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    xsi_set_current_line(180, ng0);
    t2 = (t0 + 2308);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t11, 0, 8);
    xsi_vlog_unsigned_add(t11, 10, t4, 10, t5, 10);
    t7 = (t0 + 2308);
    xsi_vlogvar_wait_assign_value(t7, t11, 0, 0, 10, 0LL);
    xsi_set_current_line(181, ng0);
    t2 = (t0 + 1252U);
    t3 = *((char **)t2);
    t2 = (t0 + 1228U);
    t4 = (t2 + 44U);
    t5 = *((char **)t4);
    t7 = (t0 + 2308);
    t9 = (t7 + 36U);
    t10 = *((char **)t9);
    xsi_vlog_generic_get_index_select_value(t11, 1, t3, t5, 2, t10, 10, 2);
    t30 = ((char*)((ng1)));
    memset(t20, 0, 8);
    t31 = (t11 + 4);
    t32 = (t30 + 4);
    t12 = *((unsigned int *)t11);
    t13 = *((unsigned int *)t30);
    t14 = (t12 ^ t13);
    t15 = *((unsigned int *)t31);
    t16 = *((unsigned int *)t32);
    t17 = (t15 ^ t16);
    t18 = (t14 | t17);
    t19 = *((unsigned int *)t31);
    t21 = *((unsigned int *)t32);
    t22 = (t19 | t21);
    t23 = (~(t22));
    t24 = (t18 & t23);
    if (t24 != 0)
        goto LAB66;

LAB63:    if (t22 != 0)
        goto LAB65;

LAB64:    *((unsigned int *)t20) = 1;

LAB66:    t41 = (t20 + 4);
    t25 = *((unsigned int *)t41);
    t27 = (~(t25));
    t28 = *((unsigned int *)t20);
    t29 = (t28 & t27);
    t33 = (t29 != 0);
    if (t33 > 0)
        goto LAB67;

LAB68:    xsi_set_current_line(184, ng0);
    t2 = (t0 + 3320);
    t3 = (t2 + 36U);
    t4 = *((char **)t3);
    t5 = (t0 + 3320);
    xsi_vlogvar_wait_assign_value(t5, t4, 0, 0, 128, 0LL);

LAB69:    goto LAB61;

LAB65:    t40 = (t20 + 4);
    *((unsigned int *)t20) = 1;
    *((unsigned int *)t40) = 1;
    goto LAB66;

LAB67:    xsi_set_current_line(182, ng0);
    t57 = (t0 + 1896U);
    t63 = *((char **)t57);
    t57 = (t0 + 3320);
    xsi_vlogvar_wait_assign_value(t57, t63, 0, 0, 128, 0LL);
    goto LAB69;

LAB71:    xsi_set_current_line(193, ng0);

LAB74:    xsi_set_current_line(194, ng0);
    t4 = (t0 + 1896U);
    t5 = *((char **)t4);
    t4 = (t0 + 2216);
    xsi_vlogvar_wait_assign_value(t4, t5, 0, 0, 128, 0LL);
    xsi_set_current_line(195, ng0);
    t2 = ((char*)((ng7)));
    t3 = (t0 + 2124);
    xsi_vlogvar_wait_assign_value(t3, t2, 0, 0, 1, 0LL);
    goto LAB73;

}


extern void work_m_00000000000866646224_1080470981_init()
{
	static char *pe[] = {(void *)Always_78_0,(void *)Always_85_1,(void *)Always_121_2};
	xsi_register_didat("work_m_00000000000866646224_1080470981", "isim/testbench_isim_beh.exe.sim/work/m_00000000000866646224_1080470981.didat");
	xsi_register_executes(pe);
}
